<tr>
	<td>{{id}}</td>
	<td>{{cat_name}}</td>
	<td>{{alias}}</td>
	<td><a href="/admin/categories/update/{{id}}/">Изменить</a></td>
	<td><a href="/admin/categories/del/{{id}}/">Удалить</a></td>
</tr>