<hr>
<p>id: {{id}}</p>
<form action="" method="POST">
	<input type="text" name="cat_name" value="{{cat_name}}">
	<input type="text" name="alias" value="{{alias}}">
	<input type="submit" name="change" value="Изменить">
</form>