<tr>
	<td>{{id}}</td>
	<td>{{name}}</td>
	<td>{{title}}</td>
	<td>{{description}}</td>
	<td><img src="{{img}}" alt="" width="50"></td>
	<td>{{text}}</td>
	<td>{{price}}</td>
	<td>{{price_sale}}</td>
	<td>{{cat_id}}</td>
	<td>{{brand_id}}</td>
	<td>{{view_count}}</td>
	<td>{{pubdate}}</td>
	<td>{{visible}}</td>
	<td>{{alias}}</td>
	<td><a href="/admin/goods/update/{{id}}/">Изменить</a></td>
	<td><a href="/admin/goods/del/{{id}}/">Удалить</a></td>
</tr>
